package co.appbrewery.xylophone;


import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {


}
